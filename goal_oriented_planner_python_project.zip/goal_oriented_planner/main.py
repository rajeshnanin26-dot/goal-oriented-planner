"""
Goal-Oriented Planner
A beginner-friendly command-line planner built with Python and SQLite.

Run:
    python main.py
"""

import sqlite3
from datetime import datetime, date

DB_NAME = "planner.db"


def connect_db():
    return sqlite3.connect(DB_NAME)


def initialize_database():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT,
                target_date TEXT,
                status TEXT NOT NULL DEFAULT 'In Progress',
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                goal_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                due_date TEXT,
                completed INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE
            )
        """)
        conn.execute("PRAGMA foreign_keys = ON")


def read_date(prompt, allow_blank=True):
    while True:
        value = input(prompt).strip()
        if not value and allow_blank:
            return None
        try:
            return datetime.strptime(value, "%Y-%m-%d").date().isoformat()
        except ValueError:
            print("Enter a valid date in YYYY-MM-DD format (example: 2026-12-31).")


def add_goal():
    print("\n--- Add a New Goal ---")
    title = input("Goal title: ").strip()
    if not title:
        print("Goal title cannot be empty.")
        return
    description = input("Description: ").strip()
    target_date = read_date("Target date (YYYY-MM-DD, optional): ")
    with connect_db() as conn:
        conn.execute(
            "INSERT INTO goals (title, description, target_date, created_at) VALUES (?, ?, ?, ?)",
            (title, description, target_date, datetime.now().isoformat(timespec="seconds"))
        )
    print("Goal added successfully!")


def list_goals(show_tasks=False):
    with connect_db() as conn:
        goals = conn.execute(
            "SELECT id, title, description, target_date, status FROM goals ORDER BY id DESC"
        ).fetchall()

        if not goals:
            print("\nNo goals found. Add your first goal!")
            return

        print("\n--- Your Goals ---")
        for goal_id, title, description, target_date, status in goals:
            print(f"\n[{goal_id}] {title}")
            print(f"    Status: {status} | Target: {target_date or 'Not set'}")
            if description:
                print(f"    Description: {description}")
            if show_tasks:
                tasks = conn.execute(
                    "SELECT id, title, due_date, completed FROM tasks WHERE goal_id = ? ORDER BY id",
                    (goal_id,)
                ).fetchall()
                if tasks:
                    for task_id, task_title, due, completed in tasks:
                        mark = "✓" if completed else " "
                        print(f"       [{mark}] Task {task_id}: {task_title} (Due: {due or 'Not set'})")
                else:
                    print("       No tasks yet.")


def choose_goal():
    list_goals()
    try:
        goal_id = int(input("\nEnter goal ID: "))
    except ValueError:
        print("Please enter a number.")
        return None
    with connect_db() as conn:
        exists = conn.execute("SELECT id FROM goals WHERE id = ?", (goal_id,)).fetchone()
    if not exists:
        print("Goal ID not found.")
        return None
    return goal_id


def add_task():
    print("\n--- Add a Task to a Goal ---")
    goal_id = choose_goal()
    if goal_id is None:
        return
    title = input("Task title: ").strip()
    if not title:
        print("Task title cannot be empty.")
        return
    due_date = read_date("Task due date (YYYY-MM-DD, optional): ")
    with connect_db() as conn:
        conn.execute(
            "INSERT INTO tasks (goal_id, title, due_date) VALUES (?, ?, ?)",
            (goal_id, title, due_date)
        )
    print("Task added successfully!")


def complete_task():
    print("\n--- Mark a Task Complete ---")
    list_goals(show_tasks=True)
    try:
        task_id = int(input("\nEnter task ID to mark complete: "))
    except ValueError:
        print("Please enter a number.")
        return
    with connect_db() as conn:
        result = conn.execute(
            "UPDATE tasks SET completed = 1 WHERE id = ?", (task_id,)
        )
        if result.rowcount:
            print("Task marked as complete!")
        else:
            print("Task ID not found.")


def update_goal_status():
    goal_id = choose_goal()
    if goal_id is None:
        return
    print("1. In Progress\n2. Completed\n3. Paused")
    choice = input("Choose status: ").strip()
    statuses = {"1": "In Progress", "2": "Completed", "3": "Paused"}
    if choice not in statuses:
        print("Invalid choice.")
        return
    with connect_db() as conn:
        conn.execute("UPDATE goals SET status = ? WHERE id = ?", (statuses[choice], goal_id))
    print("Goal status updated!")


def delete_goal():
    print("\n--- Delete a Goal ---")
    goal_id = choose_goal()
    if goal_id is None:
        return
    confirm = input("Delete this goal and all its tasks? (y/n): ").strip().lower()
    if confirm == "y":
        with connect_db() as conn:
            conn.execute("DELETE FROM tasks WHERE goal_id = ?", (goal_id,))
            conn.execute("DELETE FROM goals WHERE id = ?", (goal_id,))
        print("Goal deleted.")
    else:
        print("Deletion cancelled.")


def show_progress():
    with connect_db() as conn:
        total_goals = conn.execute("SELECT COUNT(*) FROM goals").fetchone()[0]
        completed_goals = conn.execute(
            "SELECT COUNT(*) FROM goals WHERE status = 'Completed'"
        ).fetchone()[0]
        total_tasks = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        completed_tasks = conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE completed = 1"
        ).fetchone()[0]

    print("\n--- Progress Summary ---")
    print(f"Goals completed: {completed_goals}/{total_goals}")
    print(f"Tasks completed: {completed_tasks}/{total_tasks}")
    if total_goals:
        print(f"Goal completion: {completed_goals / total_goals * 100:.1f}%")
    if total_tasks:
        print(f"Task completion: {completed_tasks / total_tasks * 100:.1f}%")


def show_upcoming_tasks():
    today = date.today().isoformat()
    with connect_db() as conn:
        tasks = conn.execute("""
            SELECT tasks.id, tasks.title, tasks.due_date, goals.title
            FROM tasks JOIN goals ON tasks.goal_id = goals.id
            WHERE tasks.completed = 0 AND tasks.due_date IS NOT NULL
            ORDER BY tasks.due_date
        """).fetchall()

    print("\n--- Upcoming / Overdue Tasks ---")
    upcoming = [task for task in tasks if task[2] >= today]
    overdue = [task for task in tasks if task[2] < today]
    if overdue:
        print("Overdue:")
        for task_id, title, due, goal in overdue:
            print(f"  Task {task_id}: {title} — {due} (Goal: {goal})")
    if upcoming:
        print("Upcoming:")
        for task_id, title, due, goal in upcoming:
            print(f"  Task {task_id}: {title} — {due} (Goal: {goal})")
    if not overdue and not upcoming:
        print("No pending tasks with due dates.")


def main():
    initialize_database()
    while True:
        print("""
========== GOAL-ORIENTED PLANNER ==========
1. Add a goal
2. View all goals and tasks
3. Add a task to a goal
4. Mark a task as complete
5. Update goal status
6. View progress summary
7. View upcoming / overdue tasks
8. Delete a goal
0. Exit
===========================================
""")
        choice = input("Enter your choice: ").strip()
        if choice == "1":
            add_goal()
        elif choice == "2":
            list_goals(show_tasks=True)
        elif choice == "3":
            add_task()
        elif choice == "4":
            complete_task()
        elif choice == "5":
            update_goal_status()
        elif choice == "6":
            show_progress()
        elif choice == "7":
            show_upcoming_tasks()
        elif choice == "8":
            delete_goal()
        elif choice == "0":
            print("Thank you for using Goal-Oriented Planner. Keep moving toward your goals!")
            break
        else:
            print("Invalid choice. Please select an option from 0 to 8.")


if __name__ == "__main__":
    main()
