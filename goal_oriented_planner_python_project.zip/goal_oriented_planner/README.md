# Goal-Oriented Planner (Python)

A beginner-friendly command-line application to create goals, break them into tasks, track completion, and review deadlines.

## Features
- Add and view personal goals
- Add tasks under each goal
- Mark tasks as completed
- Update goal status (In Progress, Completed, Paused)
- View goal/task completion percentages
- View upcoming and overdue tasks
- Delete goals and their tasks
- SQLite database saves your information between runs

## Requirements
- Python 3.8 or newer
- No third-party packages required

## How to run
1. Extract the ZIP file.
2. Open a terminal in the `goal_oriented_planner` folder.
3. Run:

   ```bash
   python main.py
   ```

   On some Windows installations, use `py main.py`.

4. Follow the menu displayed in the terminal.

## Date format
Enter dates as `YYYY-MM-DD`, for example `2026-12-31`. Press Enter to leave an optional date blank.

## Database
The app automatically creates `planner.db` in the same folder on first run. This file stores your goals and tasks.

## Project structure
```text
goal_oriented_planner/
├── main.py
└── README.md
```

## Concepts demonstrated
- Functions and modular programming
- Loops and conditional statements
- User input and validation
- SQLite database operations (CRUD)
- SQL table relationships
- Date handling
- Progress calculations
